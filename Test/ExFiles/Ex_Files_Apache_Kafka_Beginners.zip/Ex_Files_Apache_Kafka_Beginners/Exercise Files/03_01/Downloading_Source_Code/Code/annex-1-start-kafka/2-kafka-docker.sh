# Please see instructions at 
# https://github.com/simplesteph/kafka-stack-docker-compose