pub fn english() {
    println!("hey");
}

pub fn spanish() {
    println!("oye");
}