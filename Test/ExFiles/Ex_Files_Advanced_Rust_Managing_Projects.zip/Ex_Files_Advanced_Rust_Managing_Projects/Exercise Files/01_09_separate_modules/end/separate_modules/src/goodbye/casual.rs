pub fn english() {
    println!("see you later");
}

pub fn spanish() {
    println!("hasta luego");
}