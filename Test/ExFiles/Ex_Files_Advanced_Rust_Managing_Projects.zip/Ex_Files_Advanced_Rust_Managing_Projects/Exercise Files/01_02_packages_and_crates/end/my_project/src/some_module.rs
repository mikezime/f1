/**********************
 * some_module module *
 **********************/

pub fn mod_func() {
    println!("Calling mod_func from some_module module.");
}