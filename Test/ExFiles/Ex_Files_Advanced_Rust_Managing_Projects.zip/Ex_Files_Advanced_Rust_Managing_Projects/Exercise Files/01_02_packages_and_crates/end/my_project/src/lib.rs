/****************************
 * my_project library crate *
 ****************************/
 
pub fn lib_func() {
    println!("Calling lib_func from my_project library.");
}
